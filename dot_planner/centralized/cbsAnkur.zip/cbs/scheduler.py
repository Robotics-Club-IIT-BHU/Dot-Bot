#!/usr/bin/env python3
import sys
import rospy
sys.path.insert(0, '../')
import argparse
import yaml
import tf
from nav_msgs.msg import Path
from std_msgs.msg import Bool
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
from visualization_msgs.msg import Marker
from std_msgs.msg import Int8
from cbs.cbs import Environment,CBS

path_pub1 = rospy.Publisher('/path', Path, queue_size=0,latch=True) 
path_pub2=rospy.Publisher('/dot2/path', Path, queue_size=0,latch=True) 
path_pub3=rospy.Publisher('/dot3/path', Path, queue_size=0,latch=True) 
path_pub4=rospy.Publisher('/dot4/path', Path, queue_size=0,latch=True)
path_pub5=rospy.Publisher('/dot5/path', Path, queue_size=0,latch=True)
path_pub6=rospy.Publisher('/dot6/path', Path, queue_size=0,latch=True)
        
def publish_plan(solution,ag):
        """
        publish the global plan
        """
        
        global coords,coords2
          
        msg = Path()
        msg.header.frame_id = "map"
        msg.header.stamp = rospy.Time.now()
        for p in solution[ag]:
            pose = PoseStamped()
            pose.header.frame_id='map'
            pose.header.stamp=rospy.Time.now()
            coor=coords2[p['x']][p['y']]
            pose.pose.position.x = coor[0]
            pose.pose.position.y = coor[1]
            print(p['x'],p['y'])
            pose.pose.position.z = 0
            pose.pose.orientation.x = 0
            pose.pose.orientation.y = 0
            pose.pose.orientation.z = 0
            pose.pose.orientation.w = 1
            msg.poses.append(pose)
                       
        rospy.loginfo("Publiing Plan...")
        # print(msg)
        return msg
        

gc=[(3, 1),(5,1)]
ptg={
'm':[(1,2),(2,1),(2,3),(3,2)],
'd':[(3,2),(4,1),(4,3),(5,2)],
'k':[(5,2),(6,1),(6,3),(7,2)],
'c':[(1,4),(2,3),(2,5),(3,4)],
'b':[(3,4),(4,3),(4,5),(5,4)],
'h':[(5,4),(6,3),(6,5),(7,4)],
'p':[(1,6),(2,5),(2,7),(3,6)],
'a':[(3,6),(4,5),(4,7),(5,6)],
'j':[(5,6),(6,5),(6,7),(7,6)]
     }
pkg1=['c','b','k','m','m','m','c','k','k']
pkg2=['c','b','k','m','c','b','m','a','p']
st=[0,0]
tc=[(7,1),(7,7)]
f=0
bots=2
def trajer1(data):
    global re
    re[0]=1
def trajer2(data):
    global re
    re[1]=1
# def trajer3(data):
#     global re
#     re[2]=1
# def trajer4(data):
#     global re
#     re[3]=1
# def trajer5(data):
#     global re
#     re[4]=1
# def trajer6(data):
#     global re
#     re[5]=1
def mapper(x1,y1):
   xd=round((y1-0.1524)/0.3048)
   yd=round((x1-0.1524)/0.3048)
   gx6=4-xd
   gy6=4+yd
   return (gx6,gy6)
def imap(x1,y1):
#    return (-1.143+y1*0.1524,1.143-x1*0.1524)
    print(x1,y1)
    return coords2[x1][y1]
 
def mark(m1,m2):
    global st,gc,tc,re,pmsg,bots,minlen
    pathinitialise()
    re=[0,0]
    s=0
    msgl=[m1,m2]
    st=[0,0]
    path_pub=[path_pub1,path_pub2]
    lm=[len(m1.poses),len(m2.poses)]
    for i in range(bots):
       if lm[i]<=1:
          lm[i]=500
    print(lm)
    print("least=",min(lm))
    if min(lm)<500:
     for i in range(0,min(lm)+1):
      for j in range(bots):
         if(i==lm[j] or lm[j]==500):
            st[j]=1
      for j in range(bots):
        if st[j]==0:
          pmsg[j].poses.append(msgl[j].poses[i])
          print("Point-"+str(i),msgl[j].poses[i].pose.position.x,msgl[j].poses[i].pose.position.y)
          mapped=mapper(msgl[j].poses[i].pose.position.x,msgl[j].poses[i].pose.position.y)
          print("Point-"+str(i),mapped[0],mapped[1])
          gc[j]=mapped
        else:
           print("Point-"+str(i),gc[j][0],gc[j][1])
           imapped=imap(gc[j][0],gc[j][1])
           pose=PoseStamped()
           pose.header.frame_id='map'
           pose.header.stamp=rospy.Time.now()
           pose.pose.position.x=imapped[0]
           pose.pose.position.y=imapped[1]
           pose.pose.position.z = 0
           pose.pose.orientation.x = 0
           pose.pose.orientation.y = 0
           pose.pose.orientation.z = 0
           pose.pose.orientation.w = 1
           pmsg[j].poses.append(pose)

     for i in range(bots):
        path_pub[i].publish(pmsg[i])
     while s==0 and not rospy.is_shutdown():
       s=0
       for i in range(bots):
        s+=re[i]
     if not rospy.is_shutdown():
       targetpt()
    else:
        print("All delivered")

def dis(x1,y1,x2,y2):
      return abs(x2-x1)+abs(y2-y1)
def induct(x,y):
   if (x==3 and y==1) or (x==5 and y==1):
       return True
   else:
     return False
def targetpt():
    global gc,tc,st,ptg,pkg1,pkg2,bots,f
    ipl=[]
    spl=[]
    if f==0:
        for i in range(bots):
            spl.append((gc[i],i))
    for i in range(bots):
      if st[i]==1:
        if induct(gc[i][0],gc[i][1]):
           spl.append((gc[i],i))
        else:
           ipl.append((gc[i],i))
           
    inductpts=[(1,3),(1,5),(1,2),(1,4)]
    for p in inductpts:
      mini=500
      g=0
      if tc.count(p)==0:  
        for i in ipl:
            disi=dis(i[0][0],i[0][1],p[0],p[1])
            if disi<mini:
               posi=i[1]
               posj=i
               mini=disi
               g=1
        if g==1:
         tc[posi]=p
         ipl.remove(posj)
       
    for i in spl:
       if i[0][0]==3 and i[0][1]==1:
           if pkg1:
              dest=pkg1[0]
              print(pkg1[0])
              destlist=ptg[dest]
              for j in destlist:
                  if tc.count(j)==0:
                     targ=j
                     break
              pkg1.pop(0)
           else:
             targ=(3,1)
           tc[i[1]]=targ
       if i[0][0]==5 and i[0][1]==1:
          if pkg2:
             dest=pkg2[0]
             print(pkg2[0])
             destlist=ptg[dest]
             for j in destlist:
                if tc.count(j)==0:
                   targ=j
                   break
             pkg2.pop(0)
          else:
             targ=(5,1)
          tc[i[1]]=targ
          
    cbscalc()

def statics():
      tfl=tf.TransformListener()
      stat=[]
      for i in range(12,54):
          stat.append(i)
      for x in stat:
          tfl.waitForTransform('map','tag_'+str(x),rospy.Time.now(),rospy.Duration(3.0))
          (trans,rot)=tfl.lookupTransform('map','tag_'+str(x),rospy.Time(0))
          stadic[x]=(trans[0],trans[1])

def mapping():
    global coords2,coords
    coords2=[]
    coords=[]
    for i in range(0,9):
          col=[]
          for j in range(0,9):
             col.append((-1.143+2*j*0.1524,1.143-2*i*0.1524))
          coords.append(col)

    tag=14
    for i in range(1,8):
      col=[]
      for j in range(1,8):
         if(i%2==0 and j%2==0) or (i==0) or (j==0) or (i==8) or (j==8):
             col.append((0,0))
             continue
         print(tag)
         coords[i][j]=(stadic[tag][0],stadic[tag][1])
         tag+=1

    coords2=coords
    
def cbscalc():
    global gc,tc,bots
    print("Cbs start=",gc)
    print("Targets=",tc)
    parser = argparse.ArgumentParser()
    parser.add_argument("param", help="input file containing map and obstacles")
    parser.add_argument("output", help="output file with the schedule")
    args = parser.parse_args()

    # Read from input file
    with open(args.param, 'r') as param_file:
        try:
            param = yaml.load(param_file, Loader=yaml.FullLoader)
        except yaml.YAMLError as exc:
            print(exc)

    dimension = param["map"]["dimensions"]
    obstacles = param["map"]["obstacles"]
    agents = param['agents']
    
    for i in range(bots):
    #    print(agents[0]['start'])
       agents[i]['start']=[gc[i][0],gc[i][1]]
       agents[i]['goal']=[tc[i][0],tc[i][1]]
#    print(agents)
    env = Environment(dimension, agents, obstacles)

    # Searching
    cbs = CBS(env)
    solution = cbs.search()
    msg1=publish_plan(solution,'agent0')
    msg2=publish_plan(solution,'agent1')
    # msg3=publish_plan(solution,'agent2')
    # msg4=publish_plan(solution,'agent3')
    # msg5=publish_plan(solution,'agent4')
    # msg6=publish_plan(solution,'agent5')
    mark(msg1,msg2)
    if not solution:
        print(" Solution not found" )
def pathinitialise():
      global pmsg,bots
      for i in range(bots):
        pa = Path()
        pa.header.frame_id = "map"
        pa.header.stamp = rospy.Time.now()
        pmsg[i]=pa
    # print("Pmsg",pmsg[0])
def main():
   global f
   traj_call1=rospy.Subscriber('/trajectory_finished',Bool,trajer1,queue_size=10)
   traj_call2=rospy.Subscriber('/dot2/trajectory_finished',Bool,trajer2,queue_size=10)
#    traj_call3=rospy.Subscriber('/dot3/trajectory_finished',Bool,trajer3,queue_size=10)
#    traj_call4=rospy.Subscriber('/dot4/trajectory_finished',Bool,trajer4,queue_size=10)
#    traj_call5=rospy.Subscriber('/dot5/trajectory_finished',Bool,trajer5,queue_size=10)
#    traj_call6=rospy.Subscriber('/dot6/trajectory_finished',Bool,trajer6,queue_size=10)
   pathinitialise()
   statics()
   mapping()
   if f==0:
      targetpt()
      f=1

if __name__ == "__main__":
    rospy.init_node('talker', anonymous=True)
    stadic={}
    pa1=Path()
    pa1.header.frame_id = "map"
    pa1.header.stamp = rospy.Time.now()
    pa2=Path()
    pa2.header.frame_id="map"
    pa2.header.stamp=rospy.Time.now()
    pmsg=[pa1,pa2]
    coords=[[(0.0,0.0)]*9 for i in range(9)]
    main()
    rospy.spin()